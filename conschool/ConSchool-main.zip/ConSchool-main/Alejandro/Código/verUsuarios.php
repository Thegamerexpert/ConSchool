<?php
	$usuario = Usuario::verUsuario();
?>