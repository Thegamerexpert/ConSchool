<?php
	$usuario = Usuario::verUsuario();
?>