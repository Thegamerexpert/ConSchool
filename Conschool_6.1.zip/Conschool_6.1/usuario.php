<?php include_once "clases.php" ?>

<!DOCTYPE html>
<html lang="es">

	<head>

		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="CSS/styles.css">

	</head>

	<body>
	
		<?php Usuario::verUsuario(); ?>

	</body>

</html>